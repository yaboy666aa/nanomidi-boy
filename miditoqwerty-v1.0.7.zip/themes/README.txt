Themes:

The theme that will be loaded at startup will always be "default.theme",
no matter what. If you would like to use a different theme on startup, copy
its .theme file and rename it to "default.theme"

When you save a theme, they are saved to their .theme file.

E.g.
Select gruvbox theme in the program
Edit gruvbox theme using the Theme Editor
Click "Save theme"
gruvbox.theme would be mutated and saved