For the program to start, you need:

***An open MIDI input port (real or virtual)
	- If all MIDI input ports are inaccessible 
	(in use by other programs or otherwise), you will
	see "PortMidi: Bad pointer" as an error message.
	- To resolve this issue, close all programs which may
	be reading your MIDI input.

a "fonts" directory with at least one valid .ttf font;
*a "themes" directory;
layout_small.ini, layout_tall.ini;
portmidi.dll
SDL2.dll

- These are all provided by default.
  If you happen to misplace any component visit:
  https://github.com/ArijanJ/miditoqwerty/releases
  to re-download it.

- You can only have one instance of this program open.

[Settings]:

	The majority of your settings will be saved in "settings.dat".
	If your copy of the program appears broken, it is safe to delete 
	or rename your settings.dat file - a new one will be provided.
	
	**It is not recommended to change this file manually. If you are having
	trouble, delete it entirely, rename it or move it to a different directory.

[Fonts]:

	To expose a font face to the program, simply put its .ttf file in the fonts/ directory.

	Fonts are loaded in alphabetical order, meaning the default font will be the one
	whose first letter is closer to 'a'.

	A way to set the default font of the program is to prepend an exclamation mark to
	the font's filename and remove it from any other fonts' filename. 
	This ensures that it will always be loaded first.

	E.g.
	Arial-Regular.ttf -> !Arial.Regular.ttf 
	This would set the default font to "Arial-Regular"

[Themes]:

	Your current theme is saved on the last line of 
	settings.dat and it is loaded on startup.
	When you save a theme, its colors are saved to its .theme file.

	E.g.
	Select 'nord' theme in the program
	Edit nord theme using the Theme Editor
	Click "Save"
	nord.theme would be changed and saved
	On the next startup, nord.theme will be loaded