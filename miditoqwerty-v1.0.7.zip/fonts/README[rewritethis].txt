Fonts:

To expose a font face to the program, simply put its .ttf file in this directory.

Fonts are loaded in alphabetical order, meaning the default font will be the one
whose first letter is closer to 'a'.

A way to set the default font of the program is to prepend an exclamation mark to
the font's filename and remove it from any other fonts' filename. 
This ensures that it will always be loaded first.

E.g.
Arial-Regular.ttf -> !Arial.Regular.ttf 
This would set the default font to Arial-Regular